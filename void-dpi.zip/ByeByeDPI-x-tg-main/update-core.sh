#!/bin/bash
# Шаг 1: обновление ядра byedpi. Запускать из корня проекта (нужен git и интернет).
# Откат: git -C app/src/main/cpp/byedpi checkout ba53229
set -e
D=app/src/main/cpp/byedpi; H=app/src/main/jni/hev-socks5-tunnel
if [ -z "$(ls -A $D 2>/dev/null)" ]; then rmdir $D 2>/dev/null || true; git clone https://github.com/hufrea/byedpi.git $D
else git -C $D pull --ff-only; fi
if [ -z "$(ls -A $H 2>/dev/null)" ]; then rmdir $H 2>/dev/null || true; git clone --recursive https://github.com/heiher/hev-socks5-tunnel.git $H; fi
V=$(git -C $D describe --tags --always)
sed -i -E "s/(byedpi_version\"\)\.summary = )\"[^\"]*\"/\1\"$V\"/" app/src/main/java/io/github/romanvht/byedpi/fragments/MainSettingsFragment.kt
echo; echo "Ядро byedpi: $(git -C $D log -1 --format='%h %ad %s' --date=short)"
echo "--- .c файлы ядра, которых нет в CMakeLists (добавьте нужные; файлы win_* для Windows игнорируйте):"
for f in $D/*.c; do b=$(basename "$f"); grep -q "byedpi/$b" app/src/main/cpp/CMakeLists.txt || echo "  $b"; done
echo "--- точки входа, нужные JNI-обёртке:"
grep -q "^int main" $D/main.c && echo "  main: ok" || echo "  main: НЕ НАЙДЕН"
grep -q "server_fd" $D/*.c && echo "  server_fd: ok" || echo "  server_fd: НЕ НАЙДЕН"
echo; echo "Дальше: ./gradlew assembleDebug, затем в приложении 'Проверка стратегий'."
