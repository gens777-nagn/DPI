package io.github.romanvht.byedpi.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Живой космос: мерцающие звёзды с параллаксом, дрейфующие туманности, падающие звёзды. */
class StarfieldView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Star(
        var x: Float, var y: Float, val depth: Float, val size: Float,
        val phase: Float, val speed: Float, val warm: Boolean
    )

    private class Shoot(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float)

    private val d = resources.displayMetrics.density
    private val rnd = Random(11)
    private val stars = ArrayList<Star>()
    private val bgPaint = Paint()
    private val nebPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }

    private var violetA: Shader? = null
    private var blueB: Shader? = null
    private var mintA: Shader? = null
    private var cyanB: Shader? = null
    private var radA = 0f
    private var radB = 0f

    private var lastNs = 0L
    private var t = 0f
    private var energy = 0f
    private var target = 0f
    private var shoot: Shoot? = null
    private var nextShoot = 2.5f

    /** Включает «мятный» режим: быстрее движение, туманности меняют цвет. */
    fun setActive(active: Boolean) {
        target = if (active) 1f else 0f
    }

    private fun neb(r: Float, rgb: Int): Shader = RadialGradient(
        0f, 0f, r, intArrayOf((0x70 shl 24) or rgb, rgb), null, Shader.TileMode.CLAMP
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = RadialGradient(
            w * 0.5f, h * 0.38f, max(w, h) * 0.85f,
            intArrayOf(0xFF1D2050.toInt(), 0xFF0D0F26.toInt(), 0xFF070816.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        radA = max(w, h) * 0.55f
        radB = max(w, h) * 0.38f
        violetA = neb(radA, 0x8D68ED)
        mintA = neb(radA, 0x1FD6A5)
        blueB = neb(radB, 0x408DE5)
        cyanB = neb(radB, 0x3FD0F0)
        stars.clear()
        val count = ((w * h) / (d * d) / 6500f).toInt().coerceIn(40, 110)
        val sizes = floatArrayOf(0.9f, 1.1f, 1.3f, 1.8f, 2.4f)
        repeat(count) {
            stars.add(
                Star(
                    rnd.nextFloat() * w, rnd.nextFloat() * h,
                    0.3f + rnd.nextFloat() * 0.7f, sizes[rnd.nextInt(sizes.size)] * d,
                    rnd.nextFloat() * 6.28f, 0.8f + rnd.nextFloat() * 1.8f, rnd.nextFloat() < 0.25f
                )
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = 0L
        postInvalidateOnAnimation()
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, idle: Shader?, act: Shader?, alpha: Float) {
        c.save()
        c.translate(cx, cy)
        nebPaint.shader = idle
        nebPaint.alpha = (255 * alpha * (1f - energy)).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, r, nebPaint)
        nebPaint.shader = act
        nebPaint.alpha = (255 * alpha * energy).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, r, nebPaint)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min((now - lastNs) / 1_000_000_000f, 0.05f)
        lastNs = now
        t += dt
        energy += (target - energy) * min(1f, dt * 2.5f)

        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bgPaint)

        val breathe = 0.75f + 0.25f * sin(t * 0.5f)
        blob(c, w * 0.85f + sin(t * 0.15f) * w * 0.08f, h * 0.12f + sin(t * 0.11f + 1f) * h * 0.03f, radA, violetA, mintA, breathe)
        blob(c, w * 0.10f + sin(t * 0.12f + 2f) * w * 0.08f, h * 0.88f + sin(t * 0.10f) * h * 0.03f, radB, blueB, cyanB, breathe)

        drawStars(c, dt, w, h)
        drawShoot(c, dt, w, h)
        postInvalidateOnAnimation()
    }

    private fun drawStars(c: Canvas, dt: Float, w: Float, h: Float) {
        val boost = 1f + energy * 2.2f
        for (s in stars) {
            s.y += dt * (5f + 20f * s.depth) * d * boost
            s.x += dt * 1.5f * s.depth * d
            if (s.y > h + 4f * d) { s.y = -4f * d; s.x = rnd.nextFloat() * w }
            if (s.x > w + 4f * d) s.x = -4f * d
            val tw = 0.5f + 0.5f * sin(t * s.speed + s.phase)
            val a = 0.25f + 0.75f * tw
            val col = when {
                s.warm -> 0xFFC9B6FF.toInt()
                energy > 0.5f -> 0xFFCFFFF3.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
            val r = s.size * (0.65f + 0.35f * tw)
            starPaint.color = col
            starPaint.alpha = (255 * a * (0.4f + 0.6f * s.depth)).toInt().coerceIn(0, 255)
            c.drawCircle(s.x, s.y, r, starPaint)
            if (s.size > 1.7f * d) {
                starPaint.alpha = (255 * a * 0.12f).toInt().coerceIn(0, 255)
                c.drawCircle(s.x, s.y, r * 3.2f, starPaint)
                if (tw > 0.9f) {
                    linePaint.color = col
                    linePaint.alpha = 170
                    linePaint.strokeWidth = 0.8f * d
                    c.drawLine(s.x - r * 4f, s.y, s.x + r * 4f, s.y, linePaint)
                    c.drawLine(s.x, s.y - r * 4f, s.x, s.y + r * 4f, linePaint)
                }
            }
        }
    }

    private fun drawShoot(c: Canvas, dt: Float, w: Float, h: Float) {
        var s = shoot
        if (s == null) {
            if (t >= nextShoot) {
                s = Shoot(
                    w * (0.3f + rnd.nextFloat() * 0.65f), h * (0.02f + rnd.nextFloat() * 0.3f),
                    -(520f + rnd.nextFloat() * 300f) * d, (300f + rnd.nextFloat() * 160f) * d, 0.9f
                )
                shoot = s
            } else return
        }
        s.x += s.vx * dt
        s.y += s.vy * dt
        s.life -= dt
        if (s.life <= 0f) {
            shoot = null
            nextShoot = t + 4f + rnd.nextFloat() * 5f
            return
        }
        val tx = s.x - s.vx * 0.14f
        val ty = s.y - s.vy * 0.14f
        val fade = min(1f, s.life / 0.3f)
        linePaint.shader = LinearGradient(
            s.x, s.y, tx, ty, (((255 * fade).toInt()) shl 24) or 0xFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        linePaint.strokeWidth = 1.8f * d
        c.drawLine(s.x, s.y, tx, ty, linePaint)
        linePaint.shader = null
    }
}
