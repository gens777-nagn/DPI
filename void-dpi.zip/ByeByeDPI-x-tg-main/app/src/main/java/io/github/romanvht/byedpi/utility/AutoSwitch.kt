package io.github.romanvht.byedpi.utility

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.core.content.edit
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.services.ServiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Шаг 2: пока ByeDPI запущен, периодически проверяет YouTube через локальный SOCKS-прокси.
 * Если YouTube не открывается (а интернет есть) два раза подряд — перебирает ЗАКРЕПЛЁННЫЕ
 * стратегии и оставляет первую рабочую. Включается в настройках (по умолчанию выключено).
 */
object AutoSwitch {
    private const val TAG = "AutoSwitch"
    const val KEY = "auto_switch_enabled"
    private const val CONTROL = "connectivitycheck.gstatic.com/generate_204"
    private val YOUTUBE = listOf("www.youtube.com", "i.ytimg.com")
    private const val FIRST_DELAY = 60_000L
    private const val CHECK_EVERY = 180_000L
    private const val RECHECK = 30_000L
    private const val AFTER_RESTART = 8_000L
    private const val BACKOFF = 900_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var switching = false

    /** Вызывается из ServiceManager при каждом изменении статуса. */
    @Synchronized
    fun onStatus(app: Application, running: Boolean, mode: Mode) {
        if (switching) return // перезапуск вызван нами же — не сбиваем цикл
        job?.cancel()
        job = if (running) loop(app, mode) else null
        if (running) NetworkMemory.start(app, mode) else NetworkMemory.stop(app)
    }

    private fun loop(app: Application, mode: Mode) = scope.launch {
        delay(FIRST_DELAY)
        var fails = 0
        while (isActive) {
            val prefs = app.getPreferences()
            val auto = prefs.getBoolean(KEY, false)
            val memory = prefs.getBoolean(NetworkMemory.KEY, true)
            // Стратегия берётся из «byedpi_cmd_args» только в режиме командной строки
            if (!prefs.getCmdEnable() || (!auto && !memory)) { delay(CHECK_EVERY); continue }

            val (online, youtubeOk) = probe(app)
            if (online && youtubeOk && memory) NetworkMemory.remember(app, prefs.getCmdArgs())
            if (!auto || !online || youtubeOk) { fails = 0; delay(CHECK_EVERY); continue }

            fails++
            if (fails < 2) { delay(RECHECK); continue }
            fails = 0
            delay(if (switchToWorking(app, mode)) CHECK_EVERY else BACKOFF)
        }
    }

    /** Возвращает (есть ли интернет, открываются ли оба адреса YouTube). */
    private suspend fun probe(app: Application): Pair<Boolean, Boolean> {
        return try {
            val (ip, port) = app.getPreferences().getProxyIpAndPort()
            val result = SiteCheckUtils(ip, port.toInt())
                .checkSitesAsync(listOf(CONTROL) + YOUTUBE, 1, 7L, 3, false)
                .toMap()
            val online = (result[CONTROL] ?: 0) > 0
            val youtube = YOUTUBE.all { (result[it] ?: 0) > 0 }
            Log.i(TAG, "probe: online=$online youtube=$youtube")
            online to youtube
        } catch (e: Exception) {
            Log.e(TAG, "probe failed", e)
            false to false
        }
    }

    private suspend fun switchToWorking(app: Application, mode: Mode): Boolean {
        val prefs = app.getPreferences()
        val original = prefs.getCmdArgs()
        val candidates = HistoryUtils(app).getPinnedHistory().map { it.text }.filter { it != original }
        if (candidates.isEmpty()) { Log.w(TAG, "нет закреплённых стратегий"); return false }

        switching = true
        try {
            for (cmd in candidates) {
                apply(app, mode, cmd)
                delay(AFTER_RESTART)
                val (online, youtubeOk) = probe(app)
                if (online && youtubeOk) {
                    NetworkMemory.remember(app, cmd)
                    toast(app, R.string.auto_switch_changed)
                    return true
                }
            }
            apply(app, mode, original) // ничего не помогло — возвращаем прежнюю
            toast(app, R.string.auto_switch_failed)
            return false
        } finally {
            switching = false
        }
    }

    private suspend fun apply(app: Application, mode: Mode, cmd: String) {
        app.getPreferences().edit { putString("byedpi_cmd_args", cmd) }
        withContext(Dispatchers.Main) { ServiceManager.restart(app, mode) }
    }

    private fun toast(app: Application, res: Int) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(app, res, Toast.LENGTH_LONG).show() }
    }
}
