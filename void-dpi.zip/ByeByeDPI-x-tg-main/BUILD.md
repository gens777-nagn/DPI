# VØID DPI — сборка

## Способ 1: без компьютера (GitHub Actions)
1. Создайте приватный репозиторий на github.com и загрузите в него `void-dpi.zip` (Add file → Upload files).
2. Создайте файл `.github/workflows/build-apk.yml` (текст — в файле build-apk.yml рядом с архивом).
3. Вкладка Actions → Build VOID DPI APK → Run workflow. Через ~6 минут скачайте артефакт `void-dpi-apk`.
4. Установите `app-arm64-v8a-debug.apk` (универсальный — `app-universal-debug.apk`).
   Если сборка красная — скачайте артефакт `build-log` и пришлите ошибку.

## Способ 2: на компьютере
1. Android Studio (NDK + CMake) и Git. В корне проекта: `./update-core.sh` (скачивает byedpi и hev-socks5-tunnel).
2. `./gradlew assembleDebug` → APK в `app/build/outputs/apk/debug/`.

## Что изменено относительно ByeByeDPI × TG
- Дизайн VØID: тёмная тема, живой космос, эффекты вокруг кнопки, новая иконка.
- Автопереключение стратегии, память стратегий по сетям, подсказка про Частный DNS, блокировка QUIC (опция).
- Лицензия GPL-3.0, см. LICENSE и NOTICE.
